# NexCode Auth — Corrected Setup (v2)

Your `auth.js` was different from what I assumed last time. Here's what actually changed and why.

## What your real backend expects (from auth.js)

- **Register** → Supabase redirects verified users to: `${FRONTEND_URL}/pages/auth/verify.html`
- **Reset request** → Supabase redirects to: `${FRONTEND_URL}/pages/auth/reset-confirm.html`
- **Reset confirm** is a **backend route**, not a direct Supabase call:
  `POST /auth/reset-password/confirm`
  Header: `Authorization: Bearer <access_token>`
  Body: `{ password, refreshToken }`

My previous `reset.html` and `confirm.html` used the wrong filenames AND called Supabase directly instead of going through your backend's `/auth/reset-password/confirm` route. That mismatch is exactly the kind of thing that fails silently — Supabase would redirect correctly, but land on a page that doesn't exist, so you'd see a Live Server 404.

## Files in this fix — replace/add these exact names

```
nexcode-final/pages/auth/
├── verify.html          ← renamed from confirm.html, matches backend's register redirect
└── reset-confirm.html   ← renamed from reset.html, matches backend's reset redirect,
                            and now POSTs to /auth/reset-password/confirm correctly
```

`login.html` and `register.html` from last time are unaffected — no changes needed there.

## Step 1 — Drop in the files

Copy into your `nexcode-final` repo:
```
nexcode-final/pages/auth/verify.html
nexcode-final/pages/auth/reset-confirm.html
```

If you still have the old `confirm.html` / `reset.html` from last time, delete them — they're dead code now and will confuse you later if both exist.

## Step 2 — Check your `.env`

Your backend builds redirect URLs from `process.env.FRONTEND_URL`. Confirm it's set to your **current** Codespace frontend URL with no trailing slash:

```
FRONTEND_URL=https://YOUR-CURRENT-CODESPACE-NAME-5500.app.github.dev
```

If your Codespace was recreated since last session, this URL changed — that alone would cause the exact "not found" you're seeing, because the backend would be building redirect links to a dead subdomain.

## Step 3 — Update the API URL in both new files

Open `verify.html` and `reset-confirm.html`, find this line near the top of each `<script>`:

```js
const API = 'https://scaling-space-waddle-qrv79j4pp92x9w4-3000.app.github.dev';
```

Replace with your current backend port-3000 URL. (`verify.html` doesn't actually call the API — it just reads the hash — but `reset-confirm.html` needs it for the real POST call.)

## Step 4 (the one you actually asked for) — redirectTo is already correct in your code

Good news: you don't need to add anything to `auth.js`. Both routes already have `redirectTo` set:

```js
// register route
emailRedirectTo: `${process.env.FRONTEND_URL}/pages/auth/verify.html`

// reset-password route
redirectTo: `${process.env.FRONTEND_URL}/pages/auth/reset-confirm.html`
```

These are correct **as long as** `FRONTEND_URL` in `.env` is accurate (Step 2) and the two HTML files exist at those exact paths (Step 1). There's nothing to change in the backend code itself — the earlier "step 4" instruction assumed a different setup than what you actually have.

## Step 5 — Supabase dashboard: confirm Redirect URLs allow these paths

Supabase requires redirect URLs to be on an **allow-list**, separate from what your backend requests. Go to **Supabase → Authentication → URL Configuration → Redirect URLs** and make sure both are listed (swap in your current Codespace URL):

```
https://YOUR-CODESPACE-5500.app.github.dev/pages/auth/verify.html
https://YOUR-CODESPACE-5500.app.github.dev/pages/auth/reset-confirm.html
```

If your Codespace URL changed, the old entries are now stale — Supabase will reject the redirect even if your backend code is correct, which looks identical to a 404 from the user's side.

## About your "Live Server says not found" issue

This is almost certainly one of:
1. **Codespace URL changed** (new session = new subdomain) but `FRONTEND_URL` in `.env`, the `API` constants in your HTML files, or Supabase's Redirect URL allow-list still reference the old one
2. **Wrong file path** — Supabase redirects to `/pages/auth/verify.html` relative to `FRONTEND_URL`. If your `FRONTEND_URL` already includes `/nexcode-final` or doesn't, that changes where the browser actually looks. Test by opening the exact URL your backend would generate:
   ```
   https://YOUR-CODESPACE-5500.app.github.dev/pages/auth/verify.html
   ```
   or
   ```
   https://YOUR-CODESPACE-5500.app.github.dev/nexcode-final/pages/auth/verify.html
   ```
   Whichever one 404s tells you exactly what `FRONTEND_URL` should be.
3. **Live Server serving from the wrong root folder** — if you right-click `index.html` inside `nexcode-final` to start Live Server, the root is `nexcode-final/`, so paths should NOT include `/nexcode-final/` again. If you started Live Server from the parent folder instead, they should.

Tell me the exact URL you see in the browser bar when it says "not found" and I can pinpoint which of these it is immediately.
